import cv2
import pytesseract
import numpy as np
from PIL import Image

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract'
image = cv2.imread('drinks crop.jpeg') #potrait menu
#image = cv2.imread('landscapemenu.jpg') #landscape menu
#image = cv2.imread('menu3.jpg') #landscape menu

height, width, _ = image.shape
new_width = int(height * (3.5/4))  # Assuming 1:4 aspect ratio, width = height / 4
resized_image = cv2.resize(image, (new_width, height))

text = pytesseract.image_to_string(resized_image, lang='chi_sim')

lines = text.split('\n')

text_with_newlines = ''
for i, line in enumerate(lines):
    # Check if the line is not empty
    if line.strip() != '':
        text_with_newlines += line + '\n'
    # If the line is empty, check if the next line is also empty, if not, add a newline
    elif i < len(lines) - 1 and lines[i + 1].strip() != '':
        text_with_newlines += '\n'

print(text_with_newlines)

with open('output.txt', 'w', encoding='utf-8') as file:
    file.write(text_with_newlines)

cv2.imshow('Resized Image', resized_image)
cv2.waitKey(0)
cv2.destroyAllWindows()