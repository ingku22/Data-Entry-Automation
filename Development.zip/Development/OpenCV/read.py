import cv2 as cv

img = cv.imread("Image/menu 1.jpg")

cv.imshow("menu", img)

cv.waitKey(0)

