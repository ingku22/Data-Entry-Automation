import easyocr
import cv2
from matplotlib import pyplot as plt
import numpy as np
from PIL import Image

image = cv2.imread('Test Image/menu 1.jpg') #potrait menu

height, width, _ = image.shape
new_width = int(height * (3.5/4))  # Assuming 1:4 aspect ratio, width = height / 4
resized_image = cv2.resize(image, (new_width, height))

reader = easyocr.Reader(['ch_sim', 'en'], gpu=False)

detailed_result = reader.readtext(resized_image, detail = 1, paragraph=False)

clean_result = reader.readtext(resized_image, detail = 0, paragraph=True)

for t in detailed_result:
    print(detailed_result)

#print(f'Array length: {len(clean_result)}')

with open('output.txt', 'w', encoding='utf-8') as file:
    file.write(str(clean_result))

